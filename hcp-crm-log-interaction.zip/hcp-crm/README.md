# AI-First CRM — HCP Log Interaction Module

A field-rep tool for logging Healthcare Professional (HCP) interactions, built for
the Naukri screening assignment. Reps can log a visit either through a **structured
form** or a **conversational chat interface** — both write to the same backend.

## Architecture

```
frontend/   React + Redux Toolkit UI (form + chat, Inter font)
backend/    FastAPI + LangGraph AI agent + Groq LLM (gemma2-9b-it)
```

- **Frontend**: `react-redux` holds two slices — `interactions` (form state + saved
  records) and `chat` (message history). The form and chat panel are two views onto
  the same `/interactions` and `/chat` API.
- **Backend**: FastAPI exposes plain REST endpoints for the form path, and a `/chat`
  endpoint that hands the message to a LangGraph agent.
- **Database**: SQLAlchemy models, SQLite by default (zero setup), swap to
  Postgres/MySQL by changing `DATABASE_URL` in `backend/.env`.

## The LangGraph agent

`backend/agent.py` defines a single-node LangGraph graph. The node calls Groq's
`gemma2-9b-it` with tool-calling enabled; the LLM decides which tool(s) to invoke
based on the rep's free-text message, the tool runs against the database, and the
agent replies in plain language. This is what powers the chat interface — the rep
types "Met Dr. Rao at Apollo, discussed the new cardio drug, left 10 samples,
follow up in two weeks" and the agent logs the interaction, extracts entities, and
confirms back.

### The five tools

1. **`log_interaction`** — creates a record. If a `voice_note` (raw free text) is
   supplied, the LLM extracts summary, topics, materials, samples, and sentiment
   before saving.
2. **`edit_interaction`** — patches an existing record by id.
3. **`search_hcp`** — looks up past interactions for a given HCP name.
4. **`schedule_followup`** — creates a follow-up reminder tied to a visit.
5. **`summarize_voice_note`** — standalone LLM summarization, usable outside the
   logging flow (e.g. to preview a summary before saving).

## Running it locally

### Backend
```bash
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env   # then paste your Groq API key into .env
uvicorn main:app --reload --port 8000
```
Get a free Groq key at https://console.groq.com/keys — the assignment says to
generate a new one for this task.

### Frontend
```bash
cd frontend
npm install
npm run dev
```
Opens on http://localhost:5173 and talks to the backend at http://localhost:8000.

## What each screen does

- **Structured form**: HCP name, interaction type, date/time, attendees, topics,
  materials shared, samples distributed — mirrors the mock in the assignment brief.
- **Chat mode**: free-text box; the LangGraph agent parses it, calls the right
  tool(s), and the confirmation + extracted summary appear as a chat bubble.
- **Recent interactions**: list of saved records with the AI-generated summary,
  pulled from `GET /interactions`.

## Notes on the tech stack choices

- Tailwind/CSS kept minimal and hand-written for the mock's visual style rather
  than pulling in a component library, to keep the bundle small.
- `gemma2-9b-it` is used for both tool-routing and summarization per the
  assignment spec; `llama-3.3-70b-versatile` can be swapped in for
  `GROQ_MODEL` in `agent.py` if longer context is needed.
