from typing import List, Optional, Dict, Any
from pydantic import BaseModel


class InteractionCreate(BaseModel):
    hcp_name: str
    interaction_type: str = "Meeting"
    date: str
    time: Optional[str] = None
    attendees: List[str] = []
    topics_discussed: str = ""
    materials_shared: List[str] = []
    samples_distributed: List[str] = []
    voice_note: Optional[str] = None  # raw free text, sent through the LLM if present


class InteractionUpdate(BaseModel):
    hcp_name: Optional[str] = None
    interaction_type: Optional[str] = None
    date: Optional[str] = None
    time: Optional[str] = None
    attendees: Optional[List[str]] = None
    topics_discussed: Optional[str] = None
    materials_shared: Optional[List[str]] = None
    samples_distributed: Optional[List[str]] = None


class InteractionOut(BaseModel):
    id: int
    hcp_name: str
    interaction_type: str
    date: str
    time: Optional[str]
    attendees: List[str]
    topics_discussed: str
    materials_shared: List[str]
    samples_distributed: List[str]
    ai_summary: str
    ai_entities: Dict[str, Any]

    class Config:
        from_attributes = True


class ChatRequest(BaseModel):
    message: str
    thread_id: str = "default"


class ChatResponse(BaseModel):
    reply: str
    tool_calls: List[str] = []
    interaction: Optional[InteractionOut] = None
