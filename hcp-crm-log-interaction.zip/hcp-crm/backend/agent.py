"""
LangGraph AI agent for the HCP CRM module.

Role of the agent
------------------
The agent sits behind the "Log Interaction" screen's chat mode. Instead of a
field rep filling in a structured form, they can just describe the visit in
plain language ("Met Dr. Rao at Apollo, discussed the new cardio drug,
left 10 samples, she wants a follow-up in two weeks"). The agent:

1. Understands intent (log a new interaction, edit an existing one, look up
   an HCP, schedule a follow-up, or just summarize a voice note).
2. Picks the right tool(s) via Groq's gemma2-9b-it (tool-calling LLM).
3. Executes the tool against the database.
4. Returns a natural-language confirmation plus the structured record, so
   the same screen can render both the chat bubble and the form fields.

Five tools (Log Interaction and Edit Interaction are mandatory per the brief):
  1. log_interaction      - creates a new interaction record, using the LLM
                             to summarize free text and extract entities
                             (topics, materials, samples, sentiment).
  2. edit_interaction      - patches an existing record.
  3. search_hcp            - looks up past interactions for a given HCP.
  4. schedule_followup     - creates a follow-up reminder tied to a visit.
  5. summarize_voice_note  - pure LLM summarization utility, used standalone
                             or internally by log_interaction.
"""

import os
import json
from typing import Annotated, TypedDict, List

from dotenv import load_dotenv
from groq import Groq
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages

from database import SessionLocal, Interaction, FollowUp

load_dotenv()

GROQ_MODEL = "gemma2-9b-it"
client = Groq(api_key=os.getenv("GROQ_API_KEY"))


# ---------------------------------------------------------------------------
# Tool implementations (plain Python functions the graph nodes call)
# ---------------------------------------------------------------------------

def _llm_extract(voice_note: str) -> dict:
    """Use the LLM to summarize a voice note and pull out structured entities."""
    prompt = f"""You are a pharma CRM assistant. Read the field rep's note below and
return STRICT JSON only, no prose, with this shape:
{{
  "summary": "one paragraph summary",
  "hcp_name": "name if mentioned else null",
  "topics_discussed": "comma separated topics",
  "materials_shared": ["list", "of", "materials"],
  "samples_distributed": ["list", "of", "samples"],
  "sentiment": "positive|neutral|negative"
}}

Note: {voice_note}"""
    resp = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    text = resp.choices[0].message.content.strip()
    text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return {"summary": text, "hcp_name": None, "topics_discussed": "",
                 "materials_shared": [], "samples_distributed": [], "sentiment": "neutral"}


def tool_log_interaction(args: dict) -> dict:
    db = SessionLocal()
    try:
        ai_data = {}
        if args.get("voice_note"):
            ai_data = _llm_extract(args["voice_note"])

        record = Interaction(
            hcp_name=args.get("hcp_name") or ai_data.get("hcp_name") or "Unknown HCP",
            interaction_type=args.get("interaction_type", "Meeting"),
            date=args.get("date"),
            time=args.get("time"),
            attendees=args.get("attendees", []),
            topics_discussed=args.get("topics_discussed") or ai_data.get("topics_discussed", ""),
            materials_shared=args.get("materials_shared") or ai_data.get("materials_shared", []),
            samples_distributed=args.get("samples_distributed") or ai_data.get("samples_distributed", []),
            ai_summary=ai_data.get("summary", ""),
            ai_entities=ai_data,
        )
        db.add(record)
        db.commit()
        db.refresh(record)
        return {"status": "created", "id": record.id, "hcp_name": record.hcp_name,
                "summary": record.ai_summary}
    finally:
        db.close()


def tool_edit_interaction(args: dict) -> dict:
    db = SessionLocal()
    try:
        record = db.query(Interaction).filter(Interaction.id == args["id"]).first()
        if not record:
            return {"status": "error", "message": f"No interaction with id {args['id']}"}
        for field in ["hcp_name", "interaction_type", "date", "time", "attendees",
                       "topics_discussed", "materials_shared", "samples_distributed"]:
            if args.get(field) is not None:
                setattr(record, field, args[field])
        db.commit()
        db.refresh(record)
        return {"status": "updated", "id": record.id}
    finally:
        db.close()


def tool_search_hcp(args: dict) -> dict:
    db = SessionLocal()
    try:
        q = db.query(Interaction).filter(Interaction.hcp_name.ilike(f"%{args['hcp_name']}%"))
        rows = q.order_by(Interaction.date.desc()).limit(10).all()
        return {"status": "ok", "results": [
            {"id": r.id, "date": r.date, "topics": r.topics_discussed, "summary": r.ai_summary}
            for r in rows
        ]}
    finally:
        db.close()


def tool_schedule_followup(args: dict) -> dict:
    db = SessionLocal()
    try:
        f = FollowUp(
            interaction_id=args.get("interaction_id"),
            hcp_name=args["hcp_name"],
            note=args.get("note", ""),
            due_date=args["due_date"],
        )
        db.add(f)
        db.commit()
        db.refresh(f)
        return {"status": "scheduled", "id": f.id, "due_date": f.due_date}
    finally:
        db.close()


def tool_summarize_voice_note(args: dict) -> dict:
    return _llm_extract(args["voice_note"])


TOOLS = {
    "log_interaction": tool_log_interaction,
    "edit_interaction": tool_edit_interaction,
    "search_hcp": tool_search_hcp,
    "schedule_followup": tool_schedule_followup,
    "summarize_voice_note": tool_summarize_voice_note,
}

TOOL_SCHEMAS = [
    {"type": "function", "function": {
        "name": "log_interaction",
        "description": "Log a new HCP interaction. Pass a voice_note field with the raw text if the rep spoke/typed freeform notes so the LLM can extract structured fields.",
        "parameters": {"type": "object", "properties": {
            "hcp_name": {"type": "string"}, "interaction_type": {"type": "string"},
            "date": {"type": "string"}, "time": {"type": "string"},
            "attendees": {"type": "array", "items": {"type": "string"}},
            "topics_discussed": {"type": "string"},
            "materials_shared": {"type": "array", "items": {"type": "string"}},
            "samples_distributed": {"type": "array", "items": {"type": "string"}},
            "voice_note": {"type": "string"},
        }, "required": ["date"]},
    }},
    {"type": "function", "function": {
        "name": "edit_interaction",
        "description": "Edit an already-logged interaction by id.",
        "parameters": {"type": "object", "properties": {
            "id": {"type": "integer"}, "hcp_name": {"type": "string"},
            "interaction_type": {"type": "string"}, "date": {"type": "string"},
            "time": {"type": "string"}, "attendees": {"type": "array", "items": {"type": "string"}},
            "topics_discussed": {"type": "string"},
            "materials_shared": {"type": "array", "items": {"type": "string"}},
            "samples_distributed": {"type": "array", "items": {"type": "string"}},
        }, "required": ["id"]},
    }},
    {"type": "function", "function": {
        "name": "search_hcp",
        "description": "Search past interactions for a given HCP by name.",
        "parameters": {"type": "object", "properties": {"hcp_name": {"type": "string"}},
                        "required": ["hcp_name"]},
    }},
    {"type": "function", "function": {
        "name": "schedule_followup",
        "description": "Schedule a follow-up reminder for an HCP.",
        "parameters": {"type": "object", "properties": {
            "hcp_name": {"type": "string"}, "interaction_id": {"type": "integer"},
            "note": {"type": "string"}, "due_date": {"type": "string"},
        }, "required": ["hcp_name", "due_date"]},
    }},
    {"type": "function", "function": {
        "name": "summarize_voice_note",
        "description": "Summarize a raw voice note / free text into structured fields without saving anything.",
        "parameters": {"type": "object", "properties": {"voice_note": {"type": "string"}},
                        "required": ["voice_note"]},
    }},
]


# ---------------------------------------------------------------------------
# LangGraph state machine: agent node (LLM decides) -> tool node (executes)
# ---------------------------------------------------------------------------

class AgentState(TypedDict):
    messages: Annotated[list, add_messages]
    tool_calls_made: List[str]
    last_tool_result: dict


def agent_node(state: AgentState) -> AgentState:
    history = state["messages"]
    groq_messages = [{"role": "system", "content":
        "You are the AI assistant for a pharma field rep's CRM. Use tools to log, "
        "edit, search, or follow up on HCP interactions. Always call a tool when the "
        "user describes a visit or asks to change one; reply in plain text only for "
        "small talk or clarification."}]
    for m in history:
        role = "assistant" if m.get("role") == "assistant" else "user"
        groq_messages.append({"role": role, "content": m["content"]})

    resp = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=groq_messages,
        tools=TOOL_SCHEMAS,
        tool_choice="auto",
        temperature=0.2,
    )
    choice = resp.choices[0].message
    calls_made = list(state.get("tool_calls_made", []))
    tool_result = {}

    if choice.tool_calls:
        for call in choice.tool_calls:
            name = call.function.name
            args = json.loads(call.function.arguments or "{}")
            if name in TOOLS:
                tool_result = TOOLS[name](args)
                calls_made.append(name)
        reply_text = f"Done — {tool_result}"
    else:
        reply_text = choice.content or "Could you clarify what you'd like to log?"

    return {
        "messages": [{"role": "assistant", "content": reply_text}],
        "tool_calls_made": calls_made,
        "last_tool_result": tool_result,
    }


def build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("agent", agent_node)
    graph.set_entry_point("agent")
    graph.add_edge("agent", END)
    return graph.compile()


hcp_agent = build_graph()


def run_agent(message: str) -> dict:
    result = hcp_agent.invoke({
        "messages": [{"role": "user", "content": message}],
        "tool_calls_made": [],
        "last_tool_result": {},
    })
    return {
        "reply": result["messages"][-1]["content"],
        "tool_calls": result["tool_calls_made"],
        "tool_result": result["last_tool_result"],
    }
