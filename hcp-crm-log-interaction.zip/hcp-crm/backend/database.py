import os
from datetime import datetime

from dotenv import load_dotenv
from sqlalchemy import create_engine, Column, String, DateTime, JSON, Integer
from sqlalchemy.orm import sessionmaker, declarative_base

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./hcp_crm.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Interaction(Base):
    """A single logged HCP (Healthcare Professional) interaction."""

    __tablename__ = "interactions"

    id = Column(Integer, primary_key=True, index=True)
    hcp_name = Column(String, index=True, nullable=False)
    interaction_type = Column(String, default="Meeting")
    date = Column(String, nullable=False)
    time = Column(String, nullable=True)
    attendees = Column(JSON, default=list)
    topics_discussed = Column(String, default="")
    materials_shared = Column(JSON, default=list)
    samples_distributed = Column(JSON, default=list)
    ai_summary = Column(String, default="")
    ai_entities = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class FollowUp(Base):
    __tablename__ = "followups"

    id = Column(Integer, primary_key=True, index=True)
    interaction_id = Column(Integer, nullable=True)
    hcp_name = Column(String, nullable=False)
    note = Column(String, default="")
    due_date = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
