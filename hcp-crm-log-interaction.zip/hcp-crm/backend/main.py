from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from database import init_db, get_db, Interaction
from schemas import InteractionCreate, InteractionUpdate, InteractionOut, ChatRequest, ChatResponse
from agent import run_agent, tool_log_interaction, tool_edit_interaction

app = FastAPI(title="AI-First CRM — HCP Log Interaction API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/health")
def health():
    return {"status": "ok"}


# ---- Structured-form endpoints (used when the rep fills the form directly) ----

@app.post("/interactions", response_model=InteractionOut)
def create_interaction(payload: InteractionCreate):
    result = tool_log_interaction(payload.model_dump())
    return get_interaction(result["id"])


@app.get("/interactions", response_model=list[InteractionOut])
def list_interactions(db: Session = Depends(get_db)):
    return db.query(Interaction).order_by(Interaction.date.desc()).all()


@app.get("/interactions/{interaction_id}", response_model=InteractionOut)
def get_interaction(interaction_id: int, db: Session = Depends(get_db)):
    record = db.query(Interaction).filter(Interaction.id == interaction_id).first()
    if not record:
        raise HTTPException(404, "Interaction not found")
    return record


@app.patch("/interactions/{interaction_id}", response_model=InteractionOut)
def edit_interaction(interaction_id: int, payload: InteractionUpdate, db: Session = Depends(get_db)):
    data = payload.model_dump(exclude_unset=True)
    data["id"] = interaction_id
    result = tool_edit_interaction(data)
    if result["status"] == "error":
        raise HTTPException(404, result["message"])
    return get_interaction(interaction_id, db)


# ---- Chat endpoint (conversational mode, routes through the LangGraph agent) ----

@app.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest, db: Session = Depends(get_db)):
    result = run_agent(payload.message)
    interaction_out = None
    tool_result = result.get("tool_result") or {}
    if tool_result.get("id"):
        interaction_out = db.query(Interaction).filter(Interaction.id == tool_result["id"]).first()

    return ChatResponse(
        reply=result["reply"],
        tool_calls=result["tool_calls"],
        interaction=interaction_out,
    )
