import { useState } from 'react'
import { useDispatch } from 'react-redux'
import StructuredForm from './components/StructuredForm'
import ChatPanel from './components/ChatPanel'
import InteractionList from './components/InteractionList'
import { fetchInteractions } from './redux/interactionsSlice'

export default function App() {
  const [mode, setMode] = useState('form') // 'form' | 'chat'
  const dispatch = useDispatch()

  return (
    <div className="app-shell">
      <div className="eyebrow">AI-First CRM · HCP Module</div>
      <div className="app-header">
        <h1>Log HCP Interaction</h1>
      </div>
      <p className="subtitle">
        Capture a visit the way that's fastest for you — fill the form, or just tell the assistant what happened.
      </p>

      <div className="mode-toggle">
        <button className={mode === 'form' ? 'active' : ''} onClick={() => setMode('form')}>
          Structured form
        </button>
        <button className={mode === 'chat' ? 'active' : ''} onClick={() => setMode('chat')}>
          Chat with assistant
        </button>
      </div>

      {mode === 'form' ? <StructuredForm /> : <ChatPanel onLogged={() => dispatch(fetchInteractions())} />}

      <InteractionList />
    </div>
  )
}
