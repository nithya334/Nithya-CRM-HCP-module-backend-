import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { api } from '../api/client'

export const fetchInteractions = createAsyncThunk(
  'interactions/fetchAll',
  async () => api.listInteractions()
)

export const logInteraction = createAsyncThunk(
  'interactions/log',
  async (formData) => api.createInteraction(formData)
)

export const editInteraction = createAsyncThunk(
  'interactions/edit',
  async ({ id, changes }) => api.editInteraction(id, changes)
)

const initialFormState = {
  hcp_name: '',
  interaction_type: 'Meeting',
  date: '',
  time: '',
  attendees: [],
  topics_discussed: '',
  materials_shared: [],
  samples_distributed: [],
}

const interactionsSlice = createSlice({
  name: 'interactions',
  initialState: {
    items: [],
    form: initialFormState,
    status: 'idle',
    error: null,
  },
  reducers: {
    updateFormField(state, action) {
      const { field, value } = action.payload
      state.form[field] = value
    },
    resetForm(state) {
      state.form = initialFormState
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchInteractions.fulfilled, (state, action) => {
        state.items = action.payload
      })
      .addCase(logInteraction.pending, (state) => {
        state.status = 'saving'
      })
      .addCase(logInteraction.fulfilled, (state, action) => {
        state.status = 'idle'
        state.items.unshift(action.payload)
        state.form = initialFormState
      })
      .addCase(logInteraction.rejected, (state, action) => {
        state.status = 'idle'
        state.error = action.error.message
      })
      .addCase(editInteraction.fulfilled, (state, action) => {
        const idx = state.items.findIndex((i) => i.id === action.payload.id)
        if (idx !== -1) state.items[idx] = action.payload
      })
  },
})

export const { updateFormField, resetForm } = interactionsSlice.actions
export default interactionsSlice.reducer
