import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { api } from '../api/client'

export const sendChatMessage = createAsyncThunk(
  'chat/send',
  async (message) => {
    const response = await api.sendChat(message)
    return { userMessage: message, response }
  }
)

const chatSlice = createSlice({
  name: 'chat',
  initialState: {
    messages: [], // { role: 'user'|'assistant', content }
    sending: false,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(sendChatMessage.pending, (state, action) => {
        state.sending = true
        state.messages.push({ role: 'user', content: action.meta.arg })
      })
      .addCase(sendChatMessage.fulfilled, (state, action) => {
        state.sending = false
        state.messages.push({ role: 'assistant', content: action.payload.response.reply })
      })
      .addCase(sendChatMessage.rejected, (state, action) => {
        state.sending = false
        state.messages.push({ role: 'assistant', content: `Error: ${action.error.message}` })
      })
  },
})

export default chatSlice.reducer
