const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    const body = await res.text()
    throw new Error(`API error ${res.status}: ${body}`)
  }
  return res.json()
}

export const api = {
  listInteractions: () => request('/interactions'),
  createInteraction: (data) =>
    request('/interactions', { method: 'POST', body: JSON.stringify(data) }),
  editInteraction: (id, data) =>
    request(`/interactions/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  sendChat: (message) =>
    request('/chat', { method: 'POST', body: JSON.stringify({ message }) }),
}
