import { useState, useRef, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { sendChatMessage } from '../redux/chatSlice'

export default function ChatPanel() {
  const dispatch = useDispatch()
  const { messages, sending } = useSelector((s) => s.chat)
  const [draft, setDraft] = useState('')
  const scrollRef = useRef(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  const submit = (e) => {
    e.preventDefault()
    if (!draft.trim() || sending) return
    dispatch(sendChatMessage(draft.trim()))
    setDraft('')
  }

  return (
    <div className="card chat-panel">
      <div className="chat-messages" ref={scrollRef}>
        {messages.length === 0 && (
          <div className="bubble assistant">
            Tell me about a visit — e.g. "Met Dr. Rao at Apollo Hospital today, discussed
            the new cardio drug, left 10 samples, follow up in two weeks."
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`bubble ${m.role}`}>{m.content}</div>
        ))}
        {sending && <div className="bubble assistant">Thinking…</div>}
      </div>
      <form className="chat-input-row" onSubmit={submit}>
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Describe the interaction…"
        />
        <button type="submit" disabled={sending}>Send</button>
      </form>
    </div>
  )
}
