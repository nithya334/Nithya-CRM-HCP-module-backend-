import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchInteractions } from '../redux/interactionsSlice'

export default function InteractionList() {
  const dispatch = useDispatch()
  const items = useSelector((s) => s.interactions.items)

  useEffect(() => {
    dispatch(fetchInteractions())
  }, [dispatch])

  if (items.length === 0) return null

  return (
    <div className="log-list">
      <h2>Recent interactions</h2>
      {items.map((item) => (
        <div className="log-item" key={item.id}>
          <div className="hcp">{item.hcp_name}</div>
          <div className="meta">{item.date} {item.time || ''} · {item.interaction_type}</div>
          {item.ai_summary && <div className="summary">{item.ai_summary}</div>}
        </div>
      ))}
    </div>
  )
}
