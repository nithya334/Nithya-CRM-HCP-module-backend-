import { useDispatch, useSelector } from 'react-redux'
import { updateFormField, logInteraction } from '../redux/interactionsSlice'

const csv = (str) => str.split(',').map((s) => s.trim()).filter(Boolean)

export default function StructuredForm() {
  const dispatch = useDispatch()
  const { form, status } = useSelector((s) => s.interactions)

  const set = (field) => (e) =>
    dispatch(updateFormField({ field, value: e.target.value }))

  const setList = (field) => (e) =>
    dispatch(updateFormField({ field, value: csv(e.target.value) }))

  const submit = (e) => {
    e.preventDefault()
    dispatch(logInteraction(form))
  }

  return (
    <form className="card" onSubmit={submit}>
      <div className="form-grid">
        <div>
          <label htmlFor="hcp_name">HCP name</label>
          <input id="hcp_name" value={form.hcp_name} onChange={set('hcp_name')}
                 placeholder="Search or select HCP…" required />
        </div>
        <div>
          <label htmlFor="interaction_type">Interaction type</label>
          <select id="interaction_type" value={form.interaction_type} onChange={set('interaction_type')}>
            <option>Meeting</option>
            <option>Call</option>
            <option>Conference</option>
            <option>Email</option>
          </select>
        </div>
        <div>
          <label htmlFor="date">Date</label>
          <input id="date" type="date" value={form.date} onChange={set('date')} required />
        </div>
        <div>
          <label htmlFor="time">Time</label>
          <input id="time" type="time" value={form.time} onChange={set('time')} />
        </div>
        <div className="full">
          <label htmlFor="attendees">Attendees (comma separated)</label>
          <input id="attendees" value={form.attendees.join(', ')} onChange={setList('attendees')}
                 placeholder="Enter names…" />
        </div>
        <div className="full">
          <label htmlFor="topics">Topics discussed</label>
          <textarea id="topics" value={form.topics_discussed} onChange={set('topics_discussed')}
                     placeholder="Enter key discussion points…" />
        </div>
        <div>
          <label htmlFor="materials">Materials shared</label>
          <input id="materials" value={form.materials_shared.join(', ')} onChange={setList('materials_shared')}
                 placeholder="Brochure, leave-behind…" />
        </div>
        <div>
          <label htmlFor="samples">Samples distributed</label>
          <input id="samples" value={form.samples_distributed.join(', ')} onChange={setList('samples_distributed')}
                 placeholder="Product name, qty…" />
        </div>
      </div>
      <button className="btn-primary" type="submit" disabled={status === 'saving'}>
        {status === 'saving' ? 'Saving…' : 'Log interaction'}
      </button>
    </form>
  )
}
